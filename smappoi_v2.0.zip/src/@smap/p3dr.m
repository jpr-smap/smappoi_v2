function p3dr(xyzref);

plot3(xyzref(1,:),xyzref(2,:),xyzref(3,:),'r.');
% xlim([-400 400]); ylim([-400 400]); zlim([-400 400]);
