function out=ts;

out=['_' datestr(now,'yymmdd_HHMMSS')];

% fprintf('%s\n',['_' datestr(now,'yymmdd_HHMMSS')]); %pause(5); fprintf('\n');


