function params=readParamsFile(fnref,fn_type,varargin);
% read params file

switch fn_type
    case 'search'
        
        params=struct('outputDir',[],'listFormat','dat','imageFile',[],'modelFile',[],'maskFile',[],'aPerPix',1.0,'defocus',[70 70 0], ...
            'MTF',[0 0.935 0 0 0.64],'arbThr',[],'highThr',[],'nCores',8,'units',[],'rotationsFile',[], ...
            'F_abs',0,'psdFilterFlag',1,'sectors',[],'Cs',0.0027,'Cc',0.0027,'V_acc',300000, ...
            'deltaE',0.7,'a_i',50e-6,'binRange',15,'nBins',1024,'searchBin',1, ...
            'T_sample',100,'df_inc',50,'qThr',10,'dThr',20,'optimize_flag',0,'optThr',7, ...
            'maskCrossFlag',0,'range_degrees',2.0,'inc_degrees',0.5);
        
        fields=fieldnames(params);
        
        fid=fopen(fnref);
        lineCtr=1;
        while 1
            line = fgetl(fid);
            if ~ischar(line), break, end
            if( (isempty(strfind(line,'#')) ) & ~isempty(line) )
                lines_in{lineCtr}=line;
                lineCtr=lineCtr+1;
            end;
        end;
        fclose(fid);
        for j=1:length(lines_in)
            for k=1:length(fields)
                z=regexp(lines_in{j},fields{k},'split');
                if( length(z)>1 )
                    zz=strtrim(z{2});
                    switch fields{k}
                        case {'outputDir','imageFile','modelFile','maskFile','rotationsFile','listFormat'} % string input
                            params=setfield(params,char(fields(k)),strtrim(zz));
                        otherwise % number input
                            if( ~isempty(str2num(strtrim(zz))) )
                                params=setfield(params,char(fields(k)),str2num(strtrim(zz)));
                            else
                                params=setfield(params,char(fields(k)),strtrim(zz));
                            end;
                    end;
                end;
            end;
        end;
        
        
    case 'SP'
        
        params=[];
        
        params=struct('outputDir',[],'PDBFile',[],'aPerPix',1.0,'V_acc',300, ...
            'method','real','bArb',[],'nCores',1,'gpuFlag',0,'units',[],'chains',[]);
        
        fields=fieldnames(params);
        
        fid=fopen(fnref);
        lineCtr=1;
        while 1
            line = fgetl(fid);
            if ~ischar(line), break, end
            if( ~isempty(line) )
                if( isempty(strfind(line,'#')) )
                    lines_in{lineCtr}=line;
                    lineCtr=lineCtr+1;
                elseif( strfind(line,'#')>1 )
                    eol=strfind(line,'#')-1;
                    lines_in{lineCtr}=line(1:eol);
                    lineCtr=lineCtr+1;
                end;
            end;
        end;
        fclose(fid);
        for j=1:length(lines_in)
            for k=1:length(fields)
                z=regexp(lines_in{j},fields{k},'split');
                if( length(z)>1 )
                    zz=strtrim(z{2});
                    if( strcmp(zz(end),'/') )
                        zz=zz(1:end-1);
                    end;
                    switch fields{k}
                        case {'outputDir','PDBFile','method','chains'} % string input
                            params=setfield(params,char(fields(k)),strtrim(zz));
                        otherwise % number input
                            params=setfield(params,char(fields(k)),str2num(strtrim(zz)));
                    end;
                end;
            end;
        end;

        
        
        
    otherwise
        
        
        params=[];
        
end;
