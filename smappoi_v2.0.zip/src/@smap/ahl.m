function ahl(val)

xl=xlim;
yl=ylim;

hold on;
plot([xl(1) xl(2)],[val val],'r--');

