function outref=resizeForFFT(inref,varargin);

resize_mode='crop';
if( nargin>1 )
    try
        resize_mode=varargin{1};
    catch
        fprintf('problem reading crop/pad spec (using crop)...\n');
    end;
end;

switch resize_mode
    case 'crop'
        inc=-1;
    case 'pad'
        inc=1;
    otherwise
        inc=-1;
end;

dims_orig=size(inref);
dims_new=[];
for i=1:length(dims_orig)
    dim=dims_orig(i);
% dim=max(size(inref));
    fprintf('old dim is %d pixels...',dim);
    while 1
        f=factor(dim);
        if( ~sum(f>3) )
            break;
        end;
        dim=dim+inc;
    end;
    dims_new(i)=dim;
end;

outref=cutj(inref,dims_new);
fprintf('new dim is %d pixels.\n',dim);

