function avl(val)

xl=xlim;
yl=ylim;

hold on;
plot([val val],[yl(1) yl(2)],'r--');

