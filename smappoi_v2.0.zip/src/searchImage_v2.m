function varargout=searchImage_v2(paramsFile,varargin);
% compile with:
% /misc/local/matlab-2019a/bin/mcc -mv -I ~/ -R -singleCompThread searchImage_v2.m

global params
try
    params=smap.readParamsFile(paramsFile,'search');
catch
    fprintf('Error reading parameters file...\n');
    return;
end;
jobNum=1; serverNum=1;
if( nargin>1 )
    jobNum=str2num(varargin{1});
    if( nargin>2 )
        serverNum=str2num(varargin{2});
    end;
end;

scratchDir=fullfile(params.outputDir,'scratch');
if( exist(params.outputDir,'dir')~=7 )
    fprintf('Making new project directory... [%s]\n',params.outputDir);
    mkdir(params.outputDir);
end;
if( exist(scratchDir,'dir')~=7 )
    fprintf('Making new scratch directory... [%s]\n',scratchDir);
    mkdir(scratchDir);
end;

disp(datestr(now));
fileNum=jobNum;
fnLog=[scratchDir '/output_' smap.zp(jobNum,4) '.txt'];
fprintf('Making new logfile... [%s]\n',fnLog);
fidLog=fopen(fnLog,'w');
fprintf(fidLog,'%s\n',datestr(now,31));

fileBase='search_';
fNumPadded=smap.zp(num2str(fileNum),4);

searchDir=[scratchDir '/'];
outputDir=[params.outputDir '/'];
R=readRotationsFile(params.rotationsFile);
nIndices=size(R,3);
R_inds=smap.assignJobs(nIndices,params.nCores,jobNum);
rotationsPerFile=length(R_inds);
nRotations=rotationsPerFile;
fileMultiplier=R_inds(1)-1;
fprintf(fidLog,'job indices: [%s:%s]\n',num2str(R_inds(1)),num2str(R_inds(end)));
fprintf('job indices: [%s:%s]\n',num2str(R_inds(1)),num2str(R_inds(end)));

nRotations_full=size(R,3);

ccFlag=1;
if( isempty(params.imageFile) )
    ccFlag=0;
end;

df_init=params.defocus;
T_sample=params.T_sample;
df_inc=params.df_inc;
nDfs=1;
if( T_sample>0 )
    temp=[-T_sample/2:df_inc:T_sample/2];
    temp=temp-mean(temp);
    nDfs=length(temp);
    df_new=[repmat(params.defocus(1:2),nDfs,1)+repmat(temp',1,2) repmat(params.defocus(3),nDfs,1)]
    params.defocus=df_new;
end;
    

%
% read in the orientations to test specific to this run:
pv=zeros(nRotations,1);
pl=zeros(nRotations,1);
SD=zeros(nRotations,1);
fprintf(fidLog,'\nJob %i of %i, including %i rotations...\n',jobNum,params.nCores,nRotations);
disp(params);

if( ccFlag )
    % padding:
    imref_orig=smap.mr(params.imageFile);
    imref=imref_orig;
    if( params.searchBin>1 )
        params.aPerPix=params.aPerPix.*params.searchBin;
        imref=smap.resize_F(imref,1./params.searchBin,'newSize');
    end;
    imref=smap.resizeForFFT(imref,'crop');
    
    
    imref_copy=imref;
    Npix_im=size(imref);    
    Npix_im_norm=sqrt(prod(Npix_im));
    cp_im=floor(Npix_im./2)+1;
    if( params.maskCrossFlag )
        temp = ones(Npix_im(1),Npix_im(2),class(imref));
        imref_F=smap.ftj(imref);

        m2=mean(abs(imref_F),2);
        s2=2*std(abs(imref_F),[],2);
        inds_sub=find(abs(imref_F(:,cp_im(2)))>(m2+2.*s2));
        imref_F(inds_sub,cp_im(2))=m2(inds_sub);
        m2=mean(abs(imref_F),2);
        s2=2*std(abs(imref_F),[],2);
        inds_sub=find(abs(imref_F(:,cp_im(2)-1))>(m2+2.*s2));
        imref_F(inds_sub,cp_im(2)-1)=m2(inds_sub);
        m2=mean(abs(imref_F),2);
        s2=2*std(abs(imref_F),[],2);
        inds_sub=find(abs(imref_F(:,cp_im(2)+1))>(m2+2.*s2));
        imref_F(inds_sub,cp_im(2)+1)=m2(inds_sub);

        m2=mean(abs(imref_F),1);
        s2=2*std(abs(imref_F),[],1);
        inds_sub=find(abs(imref_F(cp_im(1),:))>(m2+2.*s2));
        imref_F(cp_im(1),inds_sub)=m2(inds_sub);
        m2=mean(abs(imref_F),1);
        s2=2*std(abs(imref_F),[],1);
        inds_sub=find(abs(imref_F(cp_im(1)-1,:))>(m2+2.*s2));
        imref_F(cp_im(1)-1,inds_sub)=m2(inds_sub);
        m2=mean(abs(imref_F),1);
        s2=2*std(abs(imref_F),[],1);
        inds_sub=find(abs(imref_F(cp_im(1)+1,:))>(m2+2.*s2));
        imref_F(cp_im(1)+1,inds_sub)=m2(inds_sub);
        
        imref_F(cp_im(1),cp_im(2))=0;
        imref=smap.iftj(imref_F);
        
    end;
    if( ~isempty(params.maskFile) )
        if( exist(params.maskFile,'file')==2 )
            mask_im=smap.mr(params.maskFile);
            Npix_mask=sqrt(length(find(mask_im(:)==1)));
%             mask_im=cropForFFT(mask_im);
            mask_im=smap.resizeForFFT(mask_im,'crop');
            fprintf(fidLog,'using mask in %s with %7.0d pixels...\n', ...
            params.maskFile,length(find(mask_im(:)==1)));
            %mask_im=ifftshift(mask_im);
        else
            mask_im=ones(size(imref,1),size(imref,2));
            Npix_mask=size(imref,1);
            fprintf(fidLog,'could not find specified mask file %s...\n',params.maskFile);
        end;
    else
        mask_im=ones(size(imref,1),size(imref,2));
        Npix_mask=size(imref,1);
        fprintf(fidLog,'no mask specified for search image...\n');
    end;
        
    if( params.psdFilterFlag )
        try
            fprintf(fidLog,'calculating PSD filter...\n');
%             fAmp=(abs(fftshift(fftn(ifftshift(imref))))./((Npix_im)));
            fAmp=(abs(fftshift(fftn(ifftshift(imref))))./Npix_im_norm);
%             fAmp_r_2d=radialmeanIm(fAmp,Npix_im); % 
%             fAmp_r_2d=radialmeanIm(fAmp); % 
            [~,fAmp_r_2d]=smap.radialmeanj(fAmp);
            fAmp_r_2d(cp_im(1),cp_im(2))=1;
            fAmp_r_inv=1./fAmp_r_2d;
            fAmp_r_inv(cp_im(1),cp_im(2))=0;
            fPSD=fAmp_r_inv;

        catch            
            fprintf(fidLog,'could not find PSD filter...\n');
            fprintf(fidLog,'not applying PSD filter...\n');
            fPSD=ones(size(imref,1),size(imref,2),'single');
            fPSD=smap.resize_F(fPSD,size(imref,1)/size(fPSD,1),'newSize');
        end;

    else
                    
        fprintf(fidLog,'not applying PSD filter...\n');
        fPSD=ones(size(imref,1),size(imref,2),'single');
        fPSD=smap.resize_F(fPSD,size(imref,1)/size(fPSD,1),'newSize');
        fPSD=ifftshift(fPSD);
        fPSD(1,1)=0;
        fPSD=fftshift(fPSD);
    end;
disp(size(imref))
disp(size(fPSD))
    imref=smap.iftj(smap.ftj(imref).*fPSD);
    imref=smap.nm(imref);
    fPSD=single(ifftshift(fPSD));
    imref_F=fftn(ifftshift(single(imref)))./Npix_im_norm;
    % if this is the first job, save a copy of the filtered image:
    if( fileNum==1 )
        try
            copyfile(paramsFile,outputDir);
        catch
        end;
        smap.mw(single(imref),[outputDir 'searchImage.mrc'],params.aPerPix);
    end;
    
    disp(['using image with ' num2str(Npix_im_norm) '^2 pixels']);
%     fullX=size(imref,1); fullY=size(imref,2);
%     fullXY=fullX*Npix_im(1);
    
end; % if( ccFlag )


% read in the scattering potential and forward transform (leave origin at center):
disp('reading SPV...');
SPV=smap.mr(params.modelFile);



if( params.searchBin>1 )
    SPV=smap.resize_F(SPV,1./params.searchBin,'newSize');
end;

Npix=single(min(size(SPV)));
Npix_c=Npix;
% V=SPV;
V=SPV+1i*params.F_abs*SPV;
V_F=double(fftshift(fftn(ifftshift(V))));
cp=floor(size(V_F,1)./2)+1;

V_F(cp,cp,cp)=0;

V_Fr=double(real(V_F));
V_Fi=double(imag(V_F));
clear SPV V V_F;

binRange=params.binRange;
nBins=params.nBins;
bins=linspace(-binRange,binRange,nBins);
N=zeros(nBins,1);

% % work out re-indexing matrices equivalent to small and large 
% % fftshifts in advance:
% fftshift:
idx_large_f = cell(1,2);
for k = 1:2
    m = Npix_im(k);
    p = ceil(m/2);
    idx_large_f{k} = single([p+1:m 1:p]);
end;
idx_small_f = cell(1,2);
for k = 1:2
    m = Npix;
    p = ceil(m/2);
    idx_small_f{k} = [p+1:m 1:p];
end;

% ifftshift:
idx_large_i = cell(1,2);
for k = 1:2
    m = Npix_im(k);
    p = floor(m/2);
    idx_large_i{k} = single([p+1:m 1:p]);
end;
idx_small_i = cell(1,2);
for k = 1:2
    m = Npix;
    p = floor(m/2);
    idx_small_i{k} = [p+1:m 1:p];
end;


[k_2d,cp]=smap.getKs(Npix,params.aPerPix);
[x,y,z]=meshgrid(1:Npix,1:Npix,1:Npix);
x0=x(:,:,cp)-cp;
y0=y(:,:,cp)-cp;
z0=zeros(Npix,Npix);
xyz=double([x0(:) y0(:) z0(:)]);
dummyX=1:size(V_Fr,1); dummyY=1:size(V_Fr,2); dummyZ=1:size(V_Fr,3);
clear x y z x0 y0 z0;

%dcMask=single(rrj(ones(Npix_im,Npix_im))>0.0015);
dcMask=single((smap.rrj(ones(Npix_im(1),Npix_im(2))).*max(Npix_im))>(21/2));

CTF=[];
temp=fftn(ifftshift(imref))./Npix_im_norm;
meanDfs=[];
CTF=smap.ctf(params.defocus,[Npix_im(1) Npix_im(2)]);
for i=1:nDfs
    CTF(:,:,i)=ifftshift(CTF(:,:,i));
end;
CTF=imag(CTF);


fnDone=[searchDir fileBase '_' fNumPadded '.dat'];

R_full=R;
R=double(R(:,:,R_inds));
R=normalizeRM(R);

allNewVals=0;
arbVals=[];

if( ccFlag )

    % % work out the shifts for padding templates out just once:
    xDim=Npix_im(2); yDim=Npix_im(1);
    oldDim=[(Npix) (Npix)];
    newDim=[(xDim) (yDim)];
    halfOldDim=[]; halfNewDim=[]; centerPixOld=[]; centerPixNew=[];
    for i=1:2
        oddOldFlag=mod(oldDim(i),2);
        if( oddOldFlag==1 )
            halfOldDim(i)=ceil(oldDim(i)./2);
            halfNewDim(i)=floor(newDim(i)./2);
            centerPixOld(i)=halfOldDim(i);
            centerPixNew(i)=halfNewDim(i)+1;
        else
            halfOldDim(i)=oldDim(i)./2;
            halfNewDim(i)=newDim(i)./2;
            centerPixOld(i)=halfOldDim(i)+1;
            centerPixNew(i)=floor(halfNewDim(i)+1);
        end;
        edges{i}=[centerPixOld(i)-newDim(i)./2 centerPixOld(i)+(newDim(i)./2)-1];
    end;
    diffSize=newDim(1)-oldDim(1);
    rowColInds={ [num2str(centerPixNew(1)-oldDim(1)./2) ':' num2str((centerPixNew(1)+oldDim(1)./2)-1)] , ...
        [num2str(centerPixNew(2)-oldDim(2)./2) ':' num2str((centerPixNew(2)+oldDim(2)./2)-1)] };
    dummy=reshape(1:(xDim)*(yDim),(yDim),(xDim));
    eval(['rowColNums=dummy(' rowColInds{1} ',' rowColInds{2} ');']);
    rowColNums=single(rowColNums);
    
    mip=ones(Npix_im(1),Npix_im(2),'single').*-1000;
    mipi=ones(Npix_im(1),Npix_im(2),'single').*-1000;
    sum1=zeros(Npix_im(1),Npix_im(2),nDfs,'double');
    sum2=zeros(Npix_im(1),Npix_im(2),nDfs,'double');    
    temp_image=zeros(Npix_im(1),Npix_im(2),'single');

    fprintf(fidLog,'computing xcorrs...\n'); tic;
else
    fprintf(fidLog,'making templates (no image to search)...\n'); 
    templates=zeros(Npix,Npix,nRotations,'single');
    tic;
end; % if( ccFlag )


% % initialize variables:
qInd=1; i=1; bgVal=[]; X=[]; Y=[]; Z=[]; output_image=[];
vi_rs=[]; projPot=[]; ew=[]; w_det=[]; template=[]; temp=[];
rMask=[]; bgVal=[]; RM=[]; xyz_r=[]; inds=[];
N_new=N;

cc=zeros(Npix_im(1),Npix_im(2),nDfs);
%
% set up GPUs:

if( ~isempty(params.units) )
    temp=mod(params.units-1,8)+1;
else
    temp=mod([0:(params.nCores-1)],8)+1
end;

gtu=temp(jobNum);
fprintf(fidLog,'getting gpu # %s...',num2str(gtu));
tic;
try
    gdev=gpuDevice(gtu);
    %gdev=gpuDevice(1);
    fprintf(fidLog,'%f seconds\n',toc);
%     reset(gdev)
catch
    fprintf(fidLog,'Failed to get gpu # %s\n',num2str(gtu));
    fidFail=fopen([scratchDir '/fail_' fNumPadded '.txt'],'w');
    fprintf(fidFail,'%s\n',datestr(now,31));
    exit;
end;

%bgVal=zeros(1,nDfs);
bgVal=0;
gpuVars={'R','xyz','cp','Npix','CTF','bgVal','rowColNums','temp_image', ...
    'imref_F','mask_im','V_Fr','V_Fi','SD', ...
    'sum1','sum2','fPSD','i','dummyX','dummyY','dummyZ', ...
    'X','Y','Z','output_image','vi_rs','projPot','ew','w_det', ...
    'template','temp','rMask','RM','xyz_r','Npix_im', ...
    'cc','inds','binRange','N_new','Npix_im_norm'}; % 'spvFilt'

for j=1:length(gpuVars)
    eval([gpuVars{j} '=gpuArray(' gpuVars{j} ');']); wait(gdev);
end;


fprintf('estimating background...'); tic;
if( ccFlag )
    % % calculate the expected value away from one unrotated template:
    X=xyz(:,1)+cp; Y=xyz(:,2)+cp; Z=xyz(:,3)+cp;
    output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,Y,X,Z); %wait(gdev);
    projPot_F=reshape(output_image,Npix,Npix); %wait(gdev);
    projPot_F(find(isnan(projPot_F)==1))=0; %wait(gdev);
    template=real(ifftn(projPot_F(idx_small_i{:})));    
    bgVal=single(nanmedian(template(:)))
end;
%bgVal=mean(bgVal);
wait(gdev);
toc

% generate templates and cross-correlate them with the image:
fprintf('starting...\n'); tic
fn_mip=[searchDir fileBase fNumPadded '_mip.mrc'];

nfp=1;
highVals=[]; 
if( isempty(params.highThr) )
    highThr=sqrt(2).*erfcinv(nfp.*2./(Npix_im(2).*Npix_im(1).*nRotations_full.*nDfs))
end;
dummyVec=1:(Npix_im(2)*Npix_im(1));
dummyIm=reshape(dummyVec,[Npix_im(1) Npix_im(2)]);

Nsaved=10*Npix_im_norm*nDfs; % more than enough for 1 sample/1D projection
Nsamples=(nRotations_full * (Npix_im(2) * Npix_im(1) * nDfs));
arbThr_temp=sqrt(2).*erfcinv(2*Nsaved/Nsamples);
arbThr_toUse=min([arbThr_temp params.arbThr]);
%params.arbThr=arbThr_toUse;
%fprintf(fidLog,'Using arbThr of %6.3f\n',params.arbThr);

disp(datestr(now));

    
%% main loop:

tic;

%pause;

for i=1:nRotations    
    
    qInd=fileMultiplier+i; RM=R(:,:,i)'; wait(gdev);
    xyz_r=(RM*xyz')'; wait(gdev);
    
    output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
    projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
    projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
        
    template=real(ifftn(projPot_F(idx_small_i{:}))); wait(gdev);
    template=template-median(template(:)); wait(gdev);
    temp_image(rowColNums)=template(idx_small_f{:}); wait(gdev);
    
    temp=fftn(temp_image(idx_large_i{:}))./Npix_im_norm; wait(gdev);
    temp=temp.*fPSD; wait(gdev);
    for j=1:nDfs
        template_F=temp.*CTF(:,:,j); wait(gdev);
        v=sum(abs(template_F(:)).^2,1,'native'); wait(gdev); % % SD normalization
        SD(i)=sqrt(v./prod(Npix_im)); wait(gdev);
        template_F=template_F./SD(i); wait(gdev);
        
        cc_F=imref_F.*conj(template_F); wait(gdev);
        cc_temp=real(ifftn(cc_F)).*Npix_im_norm; wait(gdev);
        cc(:,:,j)=cc_temp(idx_large_f{:}); wait(gdev);
    end;
    
    sum1=sum1+cc; sum2=sum2+cc.^2; wait(gdev); % % moments
    newLocs=gather(find(cc>params.arbThr)); wait(gdev);
    newVals=double(gather(cc(newLocs))); wait(gdev);
    nNewVals=(length(newVals)); wait(gdev);
    newInds=repmat(qInd,nNewVals,1); wait(gdev);
    newVals_all=([newVals newLocs newInds]); wait(gdev);
    arbVals{i}=(newVals_all); wait(gdev);
    highVals=[highVals; newVals_all((newVals_all(:,1)>highThr),:)]; wait(gdev); % % highVals
    
    if( mod(i,10)==0 )
        if( mod(i,100)==0 )
            fprintf(fidLog,'\n%d/%d ',i,nRotations);
            fprintf(fidLog,'averaging %3.0f msec. per orientation',1000.*toc./100);
            fprintf('\n%d/%d ',i,nRotations);
            fprintf('averaging %3.0f msec. per orientation',1000.*toc./100);
            if( mod(i,10000)==0 )
                if( ~isempty( highVals ) )
                    [a,b,c]=ind2sub([Npix_im(1) Npix_im(2) nDfs],highVals(:,2));
                    highLocs=[a b c];
                    list_highVals=[highVals(:,3) highVals(:,1) a b c]; % index, value, row, col, page
                    fid=fopen([outputDir 'highVals_' fNumPadded '.txt'],'w');
                    for i=1:size(list_highVals,1)
                        fprintf(fid,'%i\t%8.3f\t%i\t%i\t%i\n',list_highVals(i,:));
                    end;
                    fclose(fid);
                end;
            end;
            tic;
        end;
    end;
end;
timeElapsed=toc;
fprintf(fidLog,'%8.2f seconds to complete.\n',timeElapsed);
disp(datestr(now));

for i=1:length(gpuVars)
    eval([gpuVars{i} '=gather(' gpuVars{i} ');']); wait(gdev);
end;

%
% write the output files:

if( ccFlag )
    fn_sum1=[searchDir fileBase fNumPadded '_sum.mrc'];
    fn_sum2=[searchDir fileBase fNumPadded '_ssum.mrc'];
    fn_arb=[searchDir fileBase fNumPadded '_arb.dat'];
    fn_SD=[searchDir fileBase fNumPadded '_SD.dat'];
    
    smap.mw(single(sum1),fn_sum1,params.aPerPix);
    smap.mw(single(sum2),fn_sum2,params.aPerPix);
    
    fid=fopen(fn_SD,'w');
    fwrite(fid,single(reshape([SD]',1,length(SD))),'single');    
    fclose(fid);
    
    fprintf(fidLog,'making arbVals vector...');
    disp(datestr(now));
    fprintf(fidLog,'%s\n',datestr(now,31));
    nInVec=0;
    for i=1:nRotations
        nInVec=nInVec+size(arbVals{i},1);
    end;

    arbV=zeros(nInVec,3,'double');
    if( nInVec>0 )

    lastInd=0;
    for i=1:nRotations
        startInd=lastInd+1;
        nNew=size(arbVals{i},1);
        endInd=startInd+nNew-1;
        if( nNew>0 )
            arbV(startInd:endInd,:)=arbVals{i};
            lastInd=endInd;
        end;
    end;
    
    end;
    
    fprintf(fidLog,'done\n');
    fprintf(fidLog,'opening arbVals file...\n');
    fid=fopen(fn_arb,'w');
    fprintf(fidLog,'writing to arbVals file...\n');
    fwrite(fid,reshape(arbV',1,size(arbV,1)*3),'double');
    fprintf(fidLog,'closing arbVals file...\n');
    fclose(fid);
    fprintf(fidLog,'done with arbVals file\n');    

else
    fn_templates=[searchDir fileBase fNumPadded '_templates.mrc'];
    smap.mw(single(templates),fn_templates,params.aPerPix);
end;


fprintf(fidLog,'Done with job %i at %s\n',jobNum,datestr(now,31));

%pause;

%return

% 
%% combine output and clean up:

if( fileNum==params.nCores )
    
    
% searchDir=[params.outputDir '/'];
if( ccFlag )
    % here
    %fileTypesExpected={'mip','mipi','SD','arb','sum','ssum'};
    fileTypesExpected={'SD','arb','sum','ssum'};
else
    fileTypesExpected={'templates'};
end;

while 1
    % % get a list of existing files to combine and do sanity check:
    nFilesExpected=params.nCores;
    fprintf(fidLog,'Looking for files from %i searches...\n',nFilesExpected);

    numFound=[]; fileTypesFound={};
    A=dir([searchDir 'search_*.*']);
    ctr=1;
    for i=1:length(A)
        tempNum=regexp(A(i).name,'search_(\d{4,4})_','tokens');
        if( length(tempNum)>0 )
            numFound(ctr)=str2num(char(tempNum{1}));
            tempType=regexp(A(i).name,'search_(\d{4,4})_','split');
            tempTypeParts=regexp(tempType{2},'(\.{1,1})','split');
            fileTypesFound{ctr}=tempTypeParts{1};
            ctr=ctr+1;
        end;
    end;
    
    if( ctr>(nFilesExpected.*length(fileTypesExpected)) )
        fprintf(fidLog,'combining %i files...\n',(nFilesExpected.*length(fileTypesExpected)));
        if( params.nCores>1 )
            pause(10);
        end;
        break;
    end;
    pause(1);
end;

inds={};
for i=1:length(fileTypesExpected)
    inds{i}=find(strcmp(fileTypesFound,fileTypesExpected{i})==1);
end;

%temp=smap.mr([searchDir A(inds{1}(1)).name]);
if( ccFlag )
    % here
    %mip_group=zeros(fullX,Npix_im(1));%size(temp,1),size(temp,2));
    %mipi_group=zeros(fullX,Npix_im(1));%size(temp,1),size(temp,2));
    
    sumImage_group=zeros(Npix_im(1),Npix_im(2),nDfs);%size(temp,1),size(temp,2));
    ssumImage_group=zeros(Npix_im(1),Npix_im(2),nDfs);%size(temp,1),size(temp,2));
    
    %hist_group=zeros(1,nBins);
    %pvl=[]; 
    arbVector=[];
    SDl=[];
else
    templates_group=zeros(Npix_im(1),Npix_im(2));%size(temp,1),size(temp,2));
end; % if( ccFlag )

fid_arb=fopen([outputDir 'search_listAboveThreshold.dat'],'w');
startStopVec=zeros(nRotations_full,2,'double');
ctr_header=zeros(1,1,'double');
current_byte=zeros(1,1,'double');
av_all=[];

% % read in each file-type and combine:
for i=1:length(inds{1})
    for j=1:length(fileTypesExpected)
        fileType=fileTypesExpected{j};
        fn=[searchDir A(inds{j}(i)).name];
        switch fileType
            case 'mip'
                mip=smap.mr(fn);
                temp=mip>mip_group;
                mip_inds=find(temp==1);
                mip_group(mip_inds)=mip(mip_inds);
            case 'mipi'
                mipi=smap.mr(fn);
                mipi_group(mip_inds)=mipi(mip_inds);
            case 'sum'
                sumImage=smap.mr(fn);
                sumImage_group=sumImage_group+sumImage;
            case 'ssum'
                ssumImage=smap.mr(fn);
                ssumImage_group=ssumImage_group+ssumImage;
            case 'list'
                fid=fopen(fn,'r');
                temp=fread(fid,inf,'single');
                fclose(fid);
                peakVals=temp(1:2:end); peakTemp=temp(2:2:end);
                pv=[peakVals peakTemp];
                pvl=[pvl; pv];
            case 'SD'
                fid=fopen(fn,'r');
                temp=fread(fid,inf,'single');
                fclose(fid);
                SD=temp;
                SDl=[SDl; SD];
            case 'arb'
                %pause;
                disp(i);
                fid=fopen(fn,'r');
                temp=fread(fid,inf,'double');
                %temp=fread(fid,inf,'single');
                fclose(fid);
                %R_inds_temp=assignJobs(nRotations_full,params.nCores,i);
                %startStopVec=zeros(length(R_inds_temp),2);
                arbVals=[]; arbTemp=[]; arbInds=[];
                if( ~isempty(temp) )
                    arbVals=temp(1:3:end); arbTemp=temp(2:3:end); arbInds=temp(3:3:end);
                    av_temp=[arbInds arbTemp arbVals];
%                    fwrite(fid_arb,single(reshape(av_temp',1,size(av_temp,1)*3)),'single');
                    fwrite(fid_arb,reshape(av_temp',1,size(av_temp,1)*3),'double');
                    av_all=[av_all; av_temp];
                    tic;
                    [u,uI_start]=unique(double(arbInds),'first');
                    [~,uI_stop]=unique(double(arbInds),'last');
                    startStopVec(u,1)=uI_start+ctr_header;
                    startStopVec(u,2)=uI_stop+ctr_header;
                    
                    byte_vector=[uI_start-1].*3.*4';
                    byte_vector(:,2)=[uI_stop].*3.*4';
                    byte_vector=uint64(byte_vector);
                    byte_vector=byte_vector+current_byte;

                    startStopVec(u,:)=byte_vector;

                    current_byte=max(byte_vector(:,2));

                    toc;
                end;
                ctr_header=ctr_header+(length(arbVals));
            case 'hist'
                fid=fopen(fn,'r');
                N=fread(fid,inf,'int64')';
                fclose(fid);
                temp=reshape(N,1,nBins);
                hist_group=hist_group+temp;
            case 'templates'
                templates=smap.mr(fn);
                templates_group=cat(3,templates_group,templates);
            otherwise
                fprintf(fidLog,'file type %s not recognized...\n',fileType);
        end;
    end;
end;
fclose(fid_arb);

fid_arb_header=fopen([outputDir 'search_listAboveThreshold_header.dat'],'w');
fwrite(fid_arb_header,uint64(reshape(startStopVec',1,size(startStopVec,1)*2)),'uint64');
fclose(fid_arb_header);

if( ccFlag )
    
    nCores_opt=0;
        
    meanImage=double(sumImage_group./nRotations_full);
    squaredMeanImage=double(ssumImage_group./nRotations_full);
    SDImage=double(sqrt(squaredMeanImage-(meanImage.^2)));
    
    try
    ai=av_all(:,1); al=av_all(:,2); av=av_all(:,3);
    
    [temp_x,temp_y,temp_z]=ind2sub([Npix_im(1) Npix_im(2) nDfs],al);
    locs=[temp_x temp_y temp_z];
    
    fprintf(fidLog,'pixelwise-normalizing values above threshold...\n');
    av_norm=zeros(1,length(av),'double');
    for i=1:length(av)
        av_norm(i)=(av(i)-meanImage(locs(i,1),locs(i,2),locs(i,3)))./(SDImage(locs(i,1),locs(i,2),locs(i,3)));
    end;
    
    [av_norm,sI]=sort(av_norm,'ascend');
    ai=ai(sI);
    locs=locs(sI,:);
    
    ff=zeros([Npix_im(1) Npix_im(2) nDfs],'double');
    ff_inds=ff;
    for i=1:length(sI)
        ff(locs(i,1),locs(i,2),locs(i,3))=av_norm(i);
        ff_inds(locs(i,1),locs(i,2),locs(i,3))=ai(i);
    end;
    smap.mw(single(ff),[outputDir 'search_vals.mrc'],params.aPerPix);
    smap.mw(single(ff_inds),[outputDir 'search_qInds.mrc'],params.aPerPix);
    
    xs=gather(linspace(min(av_norm(:)),max(av_norm(:)),1e4));
    nfp=1;
    
    N_temp=hist(gather(av_norm(:)),xs);
    y_meas=sum(N_temp)-cumsum(N_temp);
    
    
    y_model=(erfc(xs./sqrt(2))./2).*Nsamples;
    SH=[xs; y_model; y_meas]';
    
    fid_SH=fopen([outputDir 'search_SH.txt'],'w');
    for jj=1:size(SH,1)
        fprintf(fid_SH,'%8.4f\t%12.3f\t%12i\n',SH(jj,:));
    end;
    fclose(fid_SH);
    
    
    catch
        
    end;
    
    try
        thr=sqrt(2).*erfcinv(2./(nRotations_full * (Npix_im(1) * Npix_im(2) * nDfs)));
        nHighVals=length(find(av_norm>thr));
        fprintf(fidLog,'found %i values above threshold\n',nHighVals);
        if( nHighVals>0 )
            highInds=find(av_norm>thr);
            highVals=av_norm(highInds);
            highLocs=locs(highInds,:);
            highInds_q=ai(highInds);
            list_highVals=[highInds_q highVals' highLocs]; % index, value, row, col, df
            fid_highVals=fopen([outputDir 'highVals.txt'],'w');
            for jj=1:size(list_highVals,1)
                fprintf(fid_highVals,'%i\t%8.3f\t%i\t%i\t%i\n',list_highVals(jj,:));
            end;
            fclose(fid_highVals);
        end;
    catch
        
        
    end;
    
    try
        hvf=dir([outputDir 'highVals_*.txt']);
        for jj=1:length(hvf)
            delete([outputDir hvf(jj).name]);
        end;
    catch
    end;
    
    
    % write combined files:
    fprintf(fidLog,'writing combined files...\n');
    smap.mw(single(meanImage),[outputDir 'search_mean.mrc'],params.aPerPix);
    smap.mw(single(SDImage),[outputDir 'search_SD.mrc'],params.aPerPix);
    
%             fid=fopen([outputDir 'search_listByRotation.dat'],'w');
%             fwrite(fid,single(reshape([list_byRotation]',1,3.*length(list_byRotation))),'single');
%             fclose(fid);
            
    fid=fopen([outputDir 'search_SDs.dat'],'w');
    fwrite(fid,single(reshape([SDl]',1,length(SDl))),'single');
    fclose(fid);
    
%             fid=fopen([outputDir 'search_hist.dat'],'w');
%             fwrite(fid,hist_group,'int64');
%             fclose(fid);
        
    
    
    %thr=0.5;
    %thr=sqrt(2).*erfcinv(2./(nRotations_full * (fullX * Npix_im(1) * nDfs)))
    ss=[]; qBest=[]; sI=[]; xy=[]; indVector=[];
    for i=1:nDfs
        [ss_temp,qBest_temp,sI_temp,xy_temp]=smap.clusterImByThr(ff(:,:,i),ff_inds(:,:,i),params.optThr,R_full);
        if( ~isempty(sI_temp) )
            ss=cat(2,ss,ss_temp);
            qBest=cat(3,qBest,normalizeRM(qBest_temp));
            xy=cat(1,xy,xy_temp);
            indVector=[indVector; repmat(i,length(ss_temp),1)];
        end;
    end;
    
    %xy=xy.*nmPerPix;
    mv=[];
    for i=1:length(ss)
        mv(i)=ss(i).MaxVal;
    end;
    
    nEl=size(xy,1)
    if( nEl>0 )
        nanmat=nan(nEl,nEl);
        
        pd_temp=squareform(pdist(xy));
        pd_mat=tril(nanmat)+pd_temp;
        pd=pd_mat(find(isnan(pd_mat(:))==0));
        qd_temp=smap.pairwiseQD(qBest,qBest);
        qd_mat=tril(nanmat)+qd_temp;
        qd=qd_mat(find(isnan(qd_mat(:))==0));
        
        s_mat=single(pd_mat<params.qThr & qd_mat<params.dThr);
        xy_tu=[]; q_tu=[]; hInds=[]; exclude_inds=[];
        for i=1:size(s_mat,1)
            if( nansum(s_mat(i,:))>0 )
                ntu=[i find(s_mat(i,:)>0)];
                mv_temp=mv(ntu);
                hInd=ntu(find(mv_temp==max(mv_temp),1,'first'));
                lInds=setdiff(ntu,hInd);
                s_mat(ntu,:)=0;
                xy_tu=[xy_tu; xy(hInd,:)];
                q_tu=cat(3,q_tu,qBest(:,:,hInd));
                hInds=[hInds; hInd];
                exclude_inds=[exclude_inds lInds];
            end;
        end;
        exclude_inds=unique(exclude_inds);
        keep_inds=setdiff(1:nEl,exclude_inds);
        
        nFound=length(keep_inds);
        
        fprintf(fidLog,'starting optimization on %i particles...\n',nFound);
        fprintf('starting optimization on %i particles...\n',nFound);
        
        xy_tu=xy(keep_inds,:);
        q_tu=qBest(:,:,keep_inds);
        ss_tu=ss(keep_inds);
        indVector_tu=indVector(keep_inds);
        df_tu=params.defocus(indVector_tu,:);
        qInds_tu=[];
        for i=1:nFound
            qInds_tu(i)=ff_inds(xy_tu(i,1),xy_tu(i,2),indVector_tu(i));
        end;
        pd_tu=squareform(pdist(xy_tu));
        qd_tu=smap.pairwiseQD(q_tu,q_tu);
        nanmat=nan(length(keep_inds),length(keep_inds));
        pd_tu=tril(nanmat)+pd_tu;
        qd_tu=tril(nanmat)+qd_tu;
        
        
        
        % % parcel out jobs, write params for each:
        
        nCores_opt=min([nFound params.nCores])
        inds_opt=cell(1,nCores_opt); %toOpt=cell(1,nCores);
        for i=1:nCores_opt
            %inds_opt{i}=assignJobs(nFound,nCores_opt,i);
            inds_opt{i}=[i:nCores_opt:nFound];
            if( ~isempty(inds_opt{i}) )
                xy=xy_tu(inds_opt{i},:);
                qInds=qInds_tu(inds_opt{i});
                df=df_tu(inds_opt{i},:);
                toOpt=[xy df qInds']
                fn_opt=fullfile([scratchDir '/opt_toDo_' smap.zp(i,4) '.txt']);
                fid_opt=fopen(fn_opt,'w');
                fprintf(fid_opt,'%4i\t%4i\t%6.2f\t%6.2f\t%5.4f\t%i\n',toOpt');
                fclose(fid_opt);
            end;
        end;
        if( nFound<params.nCores )
            for i=(nFound+1):params.nCores
                fn_opt=fullfile([scratchDir '/opt_toDo_' smap.zp(i,4) '.txt']);
                fid_opt=fopen(fn_opt,'w');
                fclose(fid_opt);
            end;
        end;
        
    else
        fprintf(fidLog,'nothing to optimize\n');
        for i=1:params.nCores
            fn_opt=fullfile([scratchDir '/opt_toDo_' smap.zp(i,4) '.txt']);
            fid_opt=fopen(fn_opt,'w');
            fclose(fid_opt);
        end;
    end;

    
    
else
    fprintf(fidLog,'writing combined templates...\n');
    templates_group=templates_group(:,:,2:end);
    smap.mw(single(templates_group),[outputDir 'search_templates.mrc'],params.aPerPix)
end; % if( ccFlag )

end; % fileNum==params.nCores

%%
if( params.optimize_flag )

    
    %return
    
    
    
    fn_opt=fullfile([scratchDir '/opt_toDo_' smap.zp(fileNum,4) '.txt']);    
    while 1
        if( exist(fn_opt,'file')==2 )
            fprintf(fidLog,'found file...\n');
            fprintf('found file...\n');
            pause(10);
            break;
        end;
        pause(5);
        fprintf(fidLog,'waiting...\n');
    end;
    
    try
        fid=fopen(fn_opt,'r');
        A=fscanf(fid,'%f');
        fclose(fid);
    catch
        A=[];
    end;
    
    if( length(A)>=1 )
    
        
    xy_all=[A(1:6:end) A(2:6:end)]
    df_all=[A(3:6:end) A(4:6:end) A(5:6:end)]
    qInd_all=[A(6:6:end)]    

    nParticles=length(qInd_all)

    fprintf(fidLog,'starting optimization on %i particles...\n',nParticles);
    fprintf('starting optimization on %i particles...\n',nParticles);
    

    Npix=gather(Npix); 
    Npix_im=gather(Npix_im);
    Npix_im_norm=gather(Npix_im_norm);

    gpuVars={'R','xyz','CTF','bgVal','rowColNums','temp_image', ...
    'imref_F','mask_im','V_Fr','V_Fi','pv','pl','SD', ...
    'fPSD','i','qInd','dummyX','dummyY','dummyZ', ...
    'X','Y','Z','output_image','vi_rs','projPot','ew','w_det', ...
    'template','temp','rMask','RM','xyz_r', ...
    'cc','binRange','N_new'}; % 'spvFilt'

    for j=1:length(gpuVars)
        try
            eval([gpuVars{j} '=gpuArray(' gpuVars{j} ');']); wait(gdev);
        catch
        end;
    end;

    tic
    meanImage=smap.mr([outputDir 'search_mean.mrc']);
    meanImage=mean(meanImage,3);
    SDImage=smap.mr([outputDir 'search_SD.mrc']);
    SDImage=mean(SDImage,3);
    
    
    %patch_F=gpuArray.zeros(Npix,Npix,nParticles); 
    xy=[]; df=[]; qInd=[]; RM_init=[];
    for i=1:nParticles
        xy(i,:)=xy_all(i,:);
        df(i,:)=df_all(i,:);
        qInd(i)=qInd_all(i);
        RM_init(:,:,i)=R_full(:,:,qInd(i));
    end;
    %
    %
%     fPSD_patch=smap.cutj(fftshift(fPSD),Npix.*[1,1]); % make it square now
    %
    %
    fPSD_patch=ifftshift(smap.resize_F(fftshift(fPSD),Npix/min(Npix_im),'newSize')); % corner
    fPSD_patch(1,1)=0;
        
    try
        baseVec=[-params.range_degrees:params.inc_degrees:params.range_degrees];
        [xd,yd,zd]=meshgrid(baseVec,baseVec,baseVec);
        xdd=xd(:); ydd=yd(:); zdd=zd(:);
        xyz_dummy=[xdd ydd zdd];
        xyz_dummy_r=sqrt(sum(xyz_dummy.^2,2));
        itk=find(xyz_dummy_r<=params.range_degrees);
        xyz_dummy=xyz_dummy(itk,:);
        xyz_dummy_rot=xyz_dummy.*pi./180;
        R_bump=[];
        
        for i=1:size(xyz_dummy,1)
            R_bump(:,:,i)=rotationVectorToMatrix(xyz_dummy_rot(i,:));
        end;
        fprintf(fidLog,'refining over %3.2f degree range, %3.2f degree increments\n',params.range_degrees,params.inc_degrees);

    catch
        fprintf(fidLog,'refining with default rotation set...\n');
        R_bump=normalizeRM(readRotationsFile('~/smap_ij/rotation/qBump_2deg_0.5degInc.txt'));
    end;
    
    nBump=size(R_bump,3);
    Rtu=[];
    %template_F=gpuArray.zeros(Npix,Npix,nDfs,'single');
        
    xyz=gpuArray(xyz);
    
%     patch_mask=single(rrj(ones(Npix,Npix)).*Npix)<=5;
    patch_mask=single(smap.rrj(ones(Npix,Npix)).*Npix)<=5;
    inds_mask=find(patch_mask==1);
    
    fprintf(fidLog,'flag 1\n');
    cc_max_opt=zeros(nParticles,1);
    for i=1:nParticles
%         patch=cropPatchFromImage3(imref,Npix/2,xy(i,:)); % yes, PSD-filtered
        patch=smap.cropOrPad(imref,Npix.*[1 1],xy(i,:)); % yes, PSD-filtered        
        patch_F=(fftn(ifftshift(gpuArray(patch)))); % corner
%         patch_mean=cropPatchFromImage3(meanImage,Npix/2,xy(i,:));
%         patch_SD=cropPatchFromImage3(SDImage,Npix/2,xy(i,:));
        patch_mean=smap.cropOrPad(meanImage,Npix.*[1 1],xy(i,:));
        patch_SD=smap.cropOrPad(SDImage,Npix.*[1 1],xy(i,:));
        patch_mean_masked=patch_mean(inds_mask);
        patch_SD_masked=patch_SD(inds_mask);

        fprintf(fidLog,'flag 2\n');
        
%         CTF_patch=ctf(df(i,:),Npix);
        CTF_patch=smap.ctf(df(i,:),Npix.*[1,1]);
        CTF_patch=ifftshift(CTF_patch);
        temp_F=patch_F;%(:,:,i);
        patchref_F=temp_F./std(temp_F(:));
            
        RM=RM_init(:,:,i)'; %wait(gdev);
        xyz_r=(RM*xyz')'; wait(gdev); % % rotate        
        output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
        projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
        projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
        ew=exp(1i*ifftn(projPot_F(idx_small_i{:})));
        w_det=ifftn(fftn(ew).*CTF_patch);
        w_det=w_det(idx_small_f{:});
        template=real(w_det.*conj(w_det));%-bgVal;      
        template=template-median(template(:));

        fprintf(fidLog,'flag 3\n');

        temp=fftn(template(idx_small_i{:})); wait(gdev);
        temp=temp.*fPSD_patch; wait(gdev);
        temp=temp./std(temp(:)); wait(gdev);
        template_F=conj(temp);
        
        cc_F=arrayfun(@times,patchref_F,template_F); wait(gdev); % % xcorr        
        cc_temp=fftshift(real(ifftn(cc_F))).*Npix; wait(gdev);
        cc=(cc_temp(inds_mask)-patch_mean_masked)./patch_SD_masked; wait(gdev);

        fprintf(fidLog,'flag 4\n');
        
%         temp=cutj(cc,[32,32]);
%         temp_rs=resize_F(temp,32,'newSize');
%         peak_interp=gather(max(temp_rs(:)));
%         [nx,ny]=find(temp_rs==max(temp_rs(:)),1,'first');
%         cp_patch=gather(floor(Npix./2)+1);
%         (cp_patch-[ny nx])./32
%         shifts_xy=17-([nx ny]./32);
%         patch=fftshift(ifftn(patchref_F));
%         patch=applyPhaseShifts(patch,shifts_xy);        
%         patchref_F=(fftn(ifftshift((patch)))); % corner
% 
%         fprintf(fidLog,'init: %f (%f)\n',max(cc(:)),peak_interp);
%         fprintf('init: %f (%f)\n',max(cc(:)),peak_interp);

        fprintf(fidLog,'init: %f\n',max(cc(:)));
        fprintf('init: %f\n',max(cc(:)));

        toc; tic
        
        
        % % scan the defocus: 
        df1=df(i,1:2)-50;
        df2=df(i,1:2)+50;
        df_test_1=[df1(1):(params.aPerPix.*4):df2(1)]';
        df_test_2=[df1(2):(params.aPerPix.*4):df2(2)]';
        df_test_ast=repmat(df(i,3),size(df_test_1,1),1);
        df_test=[df_test_1 df_test_2 df_test_ast];
        nDfs_patch=size(df_test,1);
        
        output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
        projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
        projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
        ew=exp(1i*ifftn(projPot_F(idx_small_i{:})));

%         CTF_patch=ctf(df_test,Npix);
        CTF_patch=smap.ctf(df_test,Npix.*[1,1]);
        template_F=gpuArray.zeros(Npix,Npix);
        for j=1:nDfs_patch
            CTF_patch(:,:,j)=ifftshift(CTF_patch(:,:,j));
            w_det=ifftn(fftn(ew).*CTF_patch(:,:,j));
            w_det=w_det(idx_small_f{:});
            template=real(w_det.*conj(w_det));%-bgVal;
            template=template-median(template(:));
            
            temp=fftn(template(idx_small_i{:})); wait(gdev);
            temp=temp.*fPSD_patch; wait(gdev);
            temp=temp./std(temp(:)); wait(gdev);
            template_F(:,:,j)=conj(temp);
        end;

        fprintf(fidLog,'flag 5\n');
        
        cc_max=[];
        for j=1:nDfs_patch
            cc_F=arrayfun(@times,patchref_F,template_F(:,:,j));
            cc_temp=fftshift(real(ifftn(cc_F))).*Npix; wait(gdev);
            cc=(cc_temp(inds_mask)-patch_mean_masked)./patch_SD_masked; wait(gdev);
            cc_max(j)=gather(max(cc(:)));
        end;
        fprintf(fidLog,'defocus: %f\n',max(cc_max))
        fprintf('defocus: %f\n',max(cc_max))
        
        ind_best=find(cc_max==max(cc_max),1,'first')
        df_best=df_test(ind_best,:);
        CTF_patch=ifftshift(smap.ctf(df_best,Npix.*[1,1]));
        
        
        toc; tic
        
        
        % % now do angles:
        for j=1:nBump
            Rtu(:,:,j)=R_bump(:,:,j)*RM_init(:,:,i);
        end;
        Rtu=normalizeRM(Rtu);
        
        cc_max=[];
        %template_F=gpuArray.zeros(Npix,Npix,nBump,'single');
        for j=1:nBump
            RM=Rtu(:,:,j)';
            xyz_r=(RM*xyz')'; wait(gdev); % % rotate
            
            output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
            projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
            projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
            ew=exp(1i*ifftn(projPot_F(idx_small_i{:})));
            w_det=ifftn(fftn(ew).*CTF_patch);
            w_det=w_det(idx_small_f{:});
            template=real(w_det.*conj(w_det));%-bgVal;
            template=template-median(template(:));
            
            temp=fftn(template(idx_small_i{:})); wait(gdev);
            temp=temp.*fPSD_patch; wait(gdev);
            temp=temp./std(temp(:)); wait(gdev);
            template_F=conj(temp);

            cc_F=arrayfun(@times,patchref_F,template_F);
            cc_temp=fftshift(real(ifftn(cc_F))).*Npix; wait(gdev);
            cc=(cc_temp(inds_mask)-patch_mean_masked)./patch_SD_masked; wait(gdev);
            cc_max(j)=gather(max(cc(:)));
        end;
        fprintf(fidLog,'angle: %f\n',max(cc_max))
        fprintf('angle: %f\n',max(cc_max))

        fprintf(fidLog,'flag 6\n');
        
        ind_best=find(cc_max==max(cc_max),1,'first')
        q_best=Rtu(:,:,ind_best);

        RM=q_best';
        xyz_r=(RM*xyz')'; wait(gdev);
%         X=xyz_r(:,1)+cp;
%         Y=xyz_r(:,2)+cp;
%         Z=xyz_r(:,3)+cp;
%         output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,Y,X,Z); wait(gdev);
%         projPot_F(interp_inds)=output_image; wait(gdev);
%         
%         template=real(ifftn(projPot_F(idx_small_i{:}))); %wait(gdev);
%         template=template(idx_small_f{:});
% 
%         template_F=(fftn(ifftshift(template))); % corner
%         template_F=((template_F.*fPSD_patch)); wait(gdev);
%         v=sum(abs(template_F(:)).^2,1,'native'); wait(gdev); % % SD normalization
%         SD=sqrt(v./(Npix.^2)); wait(gdev);
%         template_F=template_F./SD; wait(gdev);
        
        toc; tic
        
        
        % %
        % % scan the defocus again:
        df1=df_best(1:2)-50;
        df2=df_best(1:2)+50;
        df_test_1=[df1(1):(params.aPerPix.*2):df2(1)]';
        df_test_2=[df1(2):(params.aPerPix.*2):df2(2)]';
        df_test_ast=repmat(df_best(3),size(df_test_1,1),1);
        df_test=[df_test_1 df_test_2 df_test_ast];
        nDfs_patch=size(df_test,1);
        
        output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
        projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
        projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
        ew=exp(1i*ifftn(projPot_F(idx_small_i{:})));

        fprintf(fidLog,'flag 7\n');

%         CTF_patch=ctf(df_test,Npix);
        CTF_patch=smap.ctf(df_test,Npix.*[1,1]);
        cc_max=[];
        template_F=gpuArray.zeros(Npix,Npix);
        for j=1:nDfs_patch
            CTF_patch(:,:,j)=ifftshift(CTF_patch(:,:,j));
            w_det=ifftn(fftn(ew).*CTF_patch(:,:,j));
            w_det=w_det(idx_small_f{:});
            template=real(w_det.*conj(w_det));%-bgVal;
            template=template-median(template(:));

            temp=fftn(template(idx_small_i{:})); wait(gdev);
            temp=temp.*fPSD_patch; wait(gdev);
            temp=temp./std(temp(:)); wait(gdev);
            template_F=conj(temp);
            cc_F=arrayfun(@times,patchref_F,template_F);
            cc_temp=fftshift(real(ifftn(cc_F))).*Npix; wait(gdev);
            cc=(cc_temp(inds_mask)-patch_mean_masked)./patch_SD_masked; wait(gdev);
            cc_max(j)=gather(max(cc(:)));
        end;
        fprintf(fidLog,'defocus: %f\n',max(cc_max))
        fprintf('defocus: %f\n',max(cc_max))
        
        ind_best=find(cc_max==max(cc_max),1,'first')
        df_best=df_test(ind_best,:)
        CTF_best=ifftshift(smap.ctf(df_best,Npix.*[1,1]));
        
        toc; tic

        % % now get the final xcorr value using the full image:
        %imref_full_F=fftn(ifftshift(gpuArray(imref)))./Npix_im;%.*fPSD;
        %imref_F=fftn(ifftshift(single(imref)))./Npix_im;
        %CTF_full=ifftshift(ctf(df_best,Npix_im));
        %iCTF=imag(CTF_full);
        %temp_F=imref_full_F.*iCTF;
        %imref_full_F=temp_F./std(temp_F(:));
                
        
        xyz_r=((q_best')*xyz')'; wait(gdev); % % rotate        
        output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
        projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
        projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
        ew=exp(1i*ifftn(projPot_F(idx_small_i{:})));
        w_det=ifftn(fftn(ew).*CTF_best);
        w_det=w_det(idx_small_f{:});
        template=real(w_det.*conj(w_det));

        fprintf(fidLog,'flag 8\n');
        
        template=template-median(template(:)); wait(gdev);
        temp_image(rowColNums)=template; wait(gdev);
        template_F=fftn(temp_image(idx_large_i{:})); wait(gdev);
        template_F=(template_F.*fPSD); wait(gdev);
        template_F=template_F./std(template_F(:)); wait(gdev);
%         

%         cc_F=imref_F.*conj(template_F); wait(gdev);
%         cc_temp=real(ifftn(cc_F)).*Npix_im; wait(gdev);
%         cc(:,:,j)=cc_temp(idx_large_f{:}); wait(gdev);
        
        cc_F=arrayfun(@times,imref_F,conj(template_F)); wait(gdev); % % xcorr
        cc_final=fftshift(real(ifftn(cc_F))).*Npix_im_norm;
        cc=(cc_final-meanImage)./SDImage; wait(gdev);
        cc_best=max(cc(:))
        [temp_x,temp_y]=find(cc==max(cc(:)),1,'first');

        fprintf(fidLog,'final (full): %f\n',cc_best)
        fprintf('final (full): %f\n',cc_best)

        toc; tic
        
        %disp('paused'); pause;
        
        outVals(i,:)=[gather(cc_best) gather(temp_x) gather(temp_y) gather(df_best) gather(double(quaternion.rotationmatrix(q_best))')]

        % %
        % % scan the defocus (full-size):
        
%         xyz_r=((q_best')*xyz')'; wait(gdev); % % rotate        
%         output_image = interp3gpu(dummyX,dummyY,dummyZ,V_Fr,V_Fi,xyz_r(:,2)+cp,xyz_r(:,1)+cp,xyz_r(:,3)+cp); wait(gdev);
%         projPot_F=reshape(output_image,Npix,Npix); wait(gdev);
%         projPot_F(find(isnan(projPot_F)==1))=0; wait(gdev);
%         template=fftshift(real(ifftn(ifftshift(projPot_F)))); wait(gdev);        
%         template=template-bgVal; wait(gdev);
%         temp_image(rowColNums)=template; wait(gdev);
%         template_F=fftn(temp_image(idx_large_i{:})); wait(gdev);
%         template_F=template_F.*fPSD;
%         template_F=template_F./std(template_F(:));
%         
%         df1=df_best(1:2)-50;
%         df2=df_best(1:2)+50;
%         df_test_1=[df1(1):(params.aPerPix.*2):df2(1)]';
%         df_test_2=[df1(2):(params.aPerPix.*2):df2(2)]';
%         df_test_ast=repmat(df_best(3),size(df_test_1,1),1);
%         df_test=[df_test_1 df_test_2 df_test_ast];
%         nDfs_full=size(df_test,1);
%         
%         CTF_full=ctf(df_test,Npix_im);
%         imref_F=gpuArray.zeros(Npix_im,Npix_im);%,size(CTF_full,3));
%         imref_full_F=fftn(ifftshift(gpuArray(imref))).*fPSD;
%         imref_full_F=imref_full_F./std(imref_full_F(:));
%         cc_max=[];
%         for j=1:nDfs_full
%             iCTF=ifftshift(imag(CTF_full(:,:,j))); 
%             iCTF=iCTF./std(iCTF(:));
%             temp_F=imref_full_F;
%             temp_F=(temp_F.*iCTF);
%             imref_F=temp_F./std(temp_F(:));
%             cc_F=arrayfun(@times,imref_F,conj(template_F)); wait(gdev); % % xcorr
%             cc_temp=real(ifftn(cc_F)).*Npix_im; wait(gdev);
%             cc_max(j)=gather(max(cc_temp(:)));
%         end;
%         
        
    end;
    
    delete(fn_opt);
    fn_opt_done=strrep(fn_opt,'opt_toDo_','opt_done_');
    fid_opt=fopen(fn_opt_done,'w');
    fprintf(fid_opt,'%6.3f\t%4i\t%4i\t%6.2f\t%6.2f\t%4.3f\t%7.6f\t%7.6f\t%7.6f\t%7.6f\n',outVals');
    fclose(fid_opt);

    else
        
        % lame, but should avoid race condition:
        try
            fprintf(fidLog,'nothing to optimize (job %i)\n',fileNum);
        catch
            
        end;
            fprintf('nothing to optimize (job %i)\n',fileNum);

        % % 042219: removing (suspect as the cause of rare non-starts in
        % the next queued job)
%         if( fileNum < params.nCores )
%             if( gtu==8 )
%                 [~,this_server]=system('uname -n');
%                 fid=fopen(['done_' strtrim(this_server) '.txt'],'w'); fclose(fid);
%             end;
% 
%             return;
%         end;
    end;
end;





if( fileNum==params.nCores )
    
    
    
    %return;
    %disp('paused');
    %pause;
    
    if( params.optimize_flag )
        

        if( nCores_opt>0 )
            
            while 1
                % % get a list of existing files to combine and do sanity check:
                nFilesExpected=nCores_opt;
                fprintf(fidLog,'Looking for files from %i optimizations...\n',nFilesExpected);
                
                
                numFound=[]; fileTypesFound={};
                A=dir([searchDir 'opt_done_*.*']);
                if( length(A)>=nFilesExpected )
                    fprintf(fidLog,'combining %i files...\n',nFilesExpected);
                    
                    % % 042219: 5 => 10 
                    pause(10);
                    
                    
                    break;
                end;
                pause(1);
            end;
            
            z=[];
            for i=1:length(A)
                fid_opt_done=fopen([searchDir A(i).name],'r');
                temp=fscanf(fid_opt_done,'%f');
                if( ~isempty(temp) )
                    z=[z; temp];
                end;
                fclose(fid_opt_done);
            end;
            
            inc=10;
            vals_final=z(1:inc:end);
            xy_final=[z(2:inc:end) z(3:inc:end)];
            df_final=[z(4:inc:end) z(5:inc:end) z(6:inc:end)];
            q_final=[z(7:inc:end) z(8:inc:end) z(9:inc:end) z(10:inc:end)];
            
            out_final=[vals_final xy_final df_final q_final];
            
            fn_final=[outputDir 'list_final.txt'];
            fid_final=fopen(fn_final,'w');
            fprintf(fid_final,'%6.3f\t%i\t%i\t%6.2f\t%6.2f\t%4.3f\t%7.6f\t%7.6f\t%7.6f\t%7.6f\n',out_final');
            fclose(fid_final);
            
        end;
        
    else
        fprintf(fidLog,'No optimization was done\n');
    end;

    fprintf(fidLog,'Done combining search output at %s\n',datestr(now,31));
    fprintf(fidLog,'Consolidating log files...\n');
    
    fclose(fidLog);
    fnFinal=[outputDir 'search.log'];
    fidFinal=fopen(fnFinal,'w');
    
    tline={''};
    for i=1:jobNum
        fn=[searchDir 'output_' smap.zp(i,4) '.txt'];
        try
            fid=fopen(fn,'r');
            while 1
                temp=fgets(fid);
                disp(temp);
                if ~ischar(temp)
                    break;
                else
                    fprintf(fidFinal,temp);
                end;
            end
            fclose(fid);
            delete(fn);
        catch
            tline{end+1}=['could not open ' fn];
            if( exist('fid','var') )
                if( fid>0 )
                    fclose(fid);
                end;
            end;
        end;
    end;
    
    % delete temp files:
    fprintf(fidLog,'deleting scratch files...\n');
    delete([searchDir '*.*']);
%     for i=1:length(inds{1})
%         for j=1:length(fileTypesExpected)
%             fileType=fileTypesExpected{j};
%             fn=[searchDir A(inds{j}(i)).name];
%             delete(fn);
%         end;
%     end;
    

    
    
    [a,b,c]=fileparts(params.outputDir);
    fn_complete='queue_complete.txt';
    try
        fid=fopen(fn_complete,'a');
        fprintf(fid,'%s\n',b);
        fclose(fid);
        fprintf(fidFinal,'%s logged\n',b);
    catch
        fprintf(fidFinal,'problem logging %s\n',b);
    end;
    
    fprintf(fidFinal,'*****\nFinished at %s\n*****',datestr(now,31));
    fclose(fidFinal);

end;


% if( gtu==8 )
%     [~,this_server]=system('uname -n');
%     pause(10);
%     fid=fopen(['done_' strtrim(this_server) '.txt'],'w'); fclose(fid);
% end;

return


%% functions called:
%%

% %%
% function y = fftshift(x,dim)
% %FFTSHIFT Shift zero-frequency component to center of spectrum.
% %   For vectors, FFTSHIFT(X) swaps the left and right halves of
% %   X.  For matrices, FFTSHIFT(X) swaps the first and third
% %   quadrants and the second and fourth quadrants.  For N-D
% %   arrays, FFTSHIFT(X) swaps "half-spaces" of X along each
% %   dimension.
% %
% %   FFTSHIFT(X,DIM) applies the FFTSHIFT operation along the 
% %   dimension DIM.
% %
% %   FFTSHIFT is useful for visualizing the Fourier transform with
% %   the zero-frequency component in the middle of the spectrum.
% %
% %   Class support for input X:
% %      float: double, single
% %
% %   See also IFFTSHIFT, FFT, FFT2, FFTN, CIRCSHIFT.
% 
% %   Copyright 1984-2004 The MathWorks, Inc.
% %   $Revision: 5.11.4.4 $  $Date: 2010/08/23 23:07:36 $
% 
%     numDims = ndims(x);
%     idx = cell(1, numDims);
%     for k = 1:numDims
%         m = size(x, k);
%         p = ceil(m/2);
%         idx{k} = [p+1:m 1:p];
%     end
% 
% % Use comma-separated list syntax for N-D indexing.
% y = x(idx{:});

%%
% function y = ifftshift(x,dim)
% %IFFTSHIFT Inverse FFT shift.
% %   For vectors, IFFTSHIFT(X) swaps the left and right halves of
% %   X.  For matrices, IFFTSHIFT(X) swaps the first and third
% %   quadrants and the second and fourth quadrants.  For N-D
% %   arrays, IFFTSHIFT(X) swaps "half-spaces" of X along each
% %   dimension.
% %
% %   IFFTSHIFT(X,DIM) applies the IFFTSHIFT operation along the 
% %   dimension DIM.
% %
% %   IFFTSHIFT undoes the effects of FFTSHIFT.
% %
% %   Class support for input X: 
% %      float: double, single
% %
% %   See also FFTSHIFT, FFT, FFT2, FFTN.
% 
% %   Copyright 1984-2004 The MathWorks, Inc.
% %   $Revision: 1.6.4.4 $  $Date: 2010/08/23 23:07:40 $
% 
%     numDims = ndims(x);
%     idx = cell(1, numDims);
%     for k = 1:numDims
%         m = size(x, k);
%         p = floor(m/2);
%         idx{k} = [p+1:m 1:p];
%     end
% 
% % Use comma-separated list syntax for N-D indexing.
% y = x(idx{:});


%%
% function rotationVector = rotationMatrixToVector(rotationMatrix)
% rotationVector=rodriguesMatrixToVector(rotationMatrix')';
% 
% %%
% function [rotationVector, dvdM] = rodriguesMatrixToVector(rotationMatrix)
% % rodriguesMatrixToVector Convert a 3D rotation matrix into a rotation
% % vector.
% %
% % rotationVector = rodriguesMatrixToVector(rotationMatrix) computes a 
% % rotation vector (axis-angle representation) corresponding to a 3D 
% % rotation matrix using the Rodrigues formula.
% %
% % rotationMatrix is a 3x3 3D rotation matrix.
% %
% % rotationVector is a 3-element rotation vector corresponding to the 
% % rotationMatrix. The vector represents the axis of rotation in 3D, and its 
% % magnitude is the rotation angle in radians.
% %
% % [..., dvdM] = rodriguesMatrixToVector(rotationMatrix) additionally
% % returns the 3-by-9 derivatives of rotationVector w.r.t rotationMatrix.
% %
% % See also vision.internal.calibration.rodriguesVectorToMatrix
% 
% % References:
% % [1] R. Hartley, A. Zisserman, "Multiple View Geometry in Computer
% %     Vision," Cambridge University Press, 2003.
% % 
% % [2] E. Trucco, A. Verri. "Introductory Techniques for 3-D Computer
% %     Vision," Prentice Hall, 1998.
% 
% % Copyright 2012 MathWorks, Inc.
% 
% %#codegen
% 
% % get the rotation matrix that is the closest approximation to the input
% [U, ~, V] = svd(rotationMatrix);
% rotationMatrix = U * V';
% 
% t = trace(rotationMatrix);
% % t is the sum of the eigenvalues of the rotationMatrix.
% % The eigenvalues are 1, cos(theta) + i sin(theta), cos(theta) - i sin(theta)
% % t = 1 + 2 cos(theta), -1 <= t <= 3
% 
% tr = (t - 1) / 2;
% theta = real(acos(tr));
% 
% r = [rotationMatrix(3,2) - rotationMatrix(2,3); ...
%      rotationMatrix(1,3) - rotationMatrix(3,1); ...
%      rotationMatrix(2,1) - rotationMatrix(1,2)];
% 
% needJacobian = nargout > 1;
% outType = class(rotationMatrix);
% 
% if needJacobian
%     dtrdM = [1 0 0 0 1 0 0 0 1] / 2;
%     dtrdM = cast(dtrdM, outType);
%     
%     drdM = [0 0 0 0 0 1 0 -1 0;...
%             0 0 -1 0 0 0 1 0 0;...
%             0 1 0 -1 0 0 0 0 0];
%     drdM = cast(drdM, outType);
% end
% 
% threshold = cast(1e-4, outType); 
% 
% if sin(theta) >= threshold
%     % theta is not close to 0 or pi
%     vth = 1 / (2*sin(theta));
%     v = r * vth;
%     rotationVector = theta * v;
% 
%     if needJacobian        
%         dthetadtr = -1/sqrt(1-tr^2);
%         dthetadM = dthetadtr * dtrdM;
%         
%         % var1 = [vth; theta]
%         dvthdtheta = -vth*cos(theta)/sin(theta);
%         dvar1dtheta = [dvthdtheta; 1];
%         dvar1dM =  dvar1dtheta * dthetadM;
% 
%         % var = [r;vth;theta]
%         dvardM = [drdM;dvar1dM];
% 
%         % var2 = [r;theta]
%         dvdvar = [vth*eye(3,outType) r zeros(3,1,outType)];
%         dthetadvar = cast([0 0 0 0 1], outType);
%         dvar2dvar = [dvdvar; dthetadvar];
% 
%         dVdvar2 = [theta*eye(3,outType) v];
% 
%         dvdM = dVdvar2 * dvar2dvar * dvardM;
%     end
% elseif t-1 > 0
%     % theta is close to 0
%     rotationVector = (.5 - (t - 3) / 12) * r;
%     if needJacobian   
%         dvdM = (-1 / 12) * r * dtrdM + (.5 - (t - 3) / 12) * drdM;
%     end
% else
%     % theta is close to pi
%     rotationVector = ...
%         computeRotationVectorForAnglesCloseToPi(rotationMatrix, theta);
%     if needJacobian
%         % No definition for this case
%         dvdM = zeros(3, 9, outType);
%     end
% end
% 
% %%
% function rotationVector = computeRotationVectorForAnglesCloseToPi(rotationMatrix, theta)
% % r = theta * v / |v|, where (w, v) is a unit quaternion.
% % This formulation is derived by going from rotation matrix to unit
% % quaternion to axis-angle
% 
% % choose the largest diagonal element to avoid a square root of a negative
% % number
% [~, a] = max(diag(rotationMatrix));
% a = a(1);
% b = mod(a, 3) + 1;
% c = mod(a+1, 3) + 1;
% 
% % compute the axis vector
% s = sqrt(rotationMatrix(a, a) - rotationMatrix(b, b) - rotationMatrix(c, c) + 1);
% v = zeros(3, 1, 'like', rotationMatrix);
% v(a) = s / 2;
% v(b) = (rotationMatrix(b, a) + rotationMatrix(a, b)) / (2 * s);
% v(c) = (rotationMatrix(c, a) + rotationMatrix(a, c)) / (2 * s);
% 
% rotationVector = theta * v / norm(v);
% 
% %%
% function rotationMatrix = rotationVectorToMatrix(rotationVector)
% 
% validateattributes(rotationVector, {'single', 'double'}, ...
%     {'real', 'nonsparse', 'vector', 'numel', 3}, mfilename, 'rotationVector');
% 
% rotationMatrix = vision.internal.calibration.rodriguesVectorToMatrix(rotationVector)';
% function [rotationMatrix, dRdr] = rodriguesVectorToMatrix(rotationVector)
% % rodriguesVectorToMatrix Convert a 3D rotation vector into a rotation
% % matrix.
% %
% % rotationMatrix = rodriguesVectorToMatrix(rotationVector) reconstructs a 
% % 3D rotationMatrix from a rotationVector (axis-angle representation) using
% % the Rodrigues formula.
% %
% % [..., dRdr] = rodriguesVectorToMatrix(rotationVector) additionally
% % returns the 9-by-3 derivatives of rotationMatrix w.r.t rotationVector.
% %
% % rotationVector is a 3-element vector representing the axis of rotation in
% % 3D. The magnitude of the vector is the rotation angle in radians.
% %
% % rotationMatrix is a 3x3 3D rotation matrix corresponding to rotationVector. 
% %
% % See also vision.internal.calibration.rodriguesMatrixToVector
% 
% % References:
% % [1] R. Hartley, A. Zisserman, "Multiple View Geometry in Computer
% %     Vision," Cambridge University Press, 2003.
% % 
% % [2] E. Trucco, A. Verri. "Introductory Techniques for 3-D Computer
% %     Vision," Prentice Hall, 1998.
% 
% % Copyright 2012 MathWorks, Inc.
% 
% %#codegen
% 
% isUsingCodeGeneration = ~isempty(coder.target);
% 
% needJacobian = (nargout > 1);
% 
% if isUsingCodeGeneration
%     if needJacobian
%         [rotationMatrix, dRdr] = rodriguesVectorToMatrixCodeGen(rotationVector);
%     else
%         rotationMatrix = rodriguesVectorToMatrixCodeGen(rotationVector);
%     end    
% else
%     if needJacobian
%         [rotationMatrix, dRdr] = visionRodriguesVectorToMatrix(rotationVector);
%     else
%         rotationMatrix = visionRodriguesVectorToMatrix(rotationVector);
%     end  
% end
% 
% %%
% function  [rotationMatrix, dRdr] = rodriguesVectorToMatrixCodeGen(rotationVector)
% theta = norm(rotationVector);
% 
% needJacobian = (nargout > 1);
% 
% if theta < 1e-6
%     rotationMatrix = eye(3, 'like', rotationVector);
%     if needJacobian
%         dRdr = [0 0 0; ...
%                 0 0 1; ...
%                 0 -1 0; ...
%                 0 0 -1; ...
%                 0 0 0; ...
%                 1 0 0; ...
%                 0 1 0; ...
%                 -1 0 0; ...
%                 0 0 0];
%         dRdr = cast(dRdr, 'like', rotationVector);
%     end
%     return;
% end
% 
% u = rotationVector ./ theta;
% u = u(:);
% w1 = u(1);
% w2 = u(2);
% w3 = u(3);
% 
% A = [  0, -w3,   w2;...
%       w3,   0,  -w1;...
%      -w2,  w1,    0];
%  
% B = u*u';
%  
% alpha   = cos(theta);
% beta    = sin(theta);
% gamma   = 1-alpha;
% 
% rotationMatrix = eye(3, 'like', rotationVector) * alpha + beta * A + gamma * B;
% 
% if needJacobian
%     I = eye(3, 'like', rotationVector);
%     
%     % m3 = [rotationVector,theta], theta = |rotationVector|
%     dm3dr = [I; u']; % 4x3
% 
%     % m2 = [u;theta]
%     dm2dm3 = [I./theta -rotationVector./theta^2; ...
%               zeros(1, 3, 'like', rotationVector) 1]; % 4x4
% 
%     % m1 = [alpha;beta;gamma;A;B];
%     dm1dm2 = zeros(21, 4, 'like', rotationVector);
%     dm1dm2(1, 4) = -beta;
%     dm1dm2(2, 4) = alpha;
%     dm1dm2(3, 4) = beta;
%     dm1dm2(4:12, 1:3) = [0 0 0 0 0 1 0 -1 0; ...
%                          0 0 -1 0 0 0 1 0 0; ...
%                          0 1 0 -1 0 0 0 0 0]';
% 
%     dm1dm2(13:21, 1) = [2*w1,w2,w3,w2,0,0,w3,0,0];
%     dm1dm2(13:21, 2) = [0,w1,0,w1,2*w2,w3,0,w3,0];
%     dm1dm2(13:21, 3) = [0,0,w1,0,0,w2,w1,w2,2*w3];
% 
%     dRdm1 = zeros(9, 21, 'like', rotationVector);
%     dRdm1([1 5 9], 1) = 1;
%     dRdm1(:, 2) = A(:);
%     dRdm1(:, 3) = B(:);
%     dRdm1(:, 4:12) = beta*eye(9, 'like', rotationVector);
%     dRdm1(:, 13:21) = gamma*eye(9, 'like', rotationVector);
% 
%     dRdr = dRdm1 * dm1dm2 * dm2dm3 * dm3dr;
% end


%%
